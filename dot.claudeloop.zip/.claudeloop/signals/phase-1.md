## Phase 1: Remove feature flag system — Already Complete

Commit `8c4dfe1` (refactor: remove feature flag system) already implements every subtask:

- **Deleted:** `src/core/featureFlag.ts`, `src/test/unit/core/featureFlag.test.ts`
- **Modified `src/extension.ts`:** Removed `shouldActivate` import and guard block
- **Modified `package.json`:** Removed `oxveil.experimental` config property and both `"when": "config.oxveil.experimental"` conditions
- **Modified `src/test/integration/extension.test.ts`:** Removed feature flag gate tests
- **Modified `.claude/skills/feature-flags.md`:** Updated to no flags until marketplace publication

**Verification:** No references to `shouldActivate`, `featureFlag`, or `oxveil.experimental` remain in source. Gate passed: 235 tests pass, lint clean, build succeeds.

No changes needed.
